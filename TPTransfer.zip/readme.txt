TPTransfer
(C)2021 Software with Brains, LLC
All rights reserved.

SOFTWARE LICENSE AGREEMENT:
By using this application, you agree to be bound by the terms and conditions
of the software license agreement set forth in this text. You are granted a
non-exclusive license to use the software according to the terms set forth in
this agreement. All ownership and copyright to the materials in this package,
both software and documentation, remain exclusively with Software with Brains,
LLC.

Duplication, Usage, and Distribution
This application may be redistributed at will, however, it may only be
distributed in its original package form and free of charge, with all
accompanying files and documentation included in the original distribution
package, including this document.

Modifications to Software
It is a violation of this license agreement to modify any of the files in
the original software package in any way, including executable (EXE)
application files or this document.

Warranty of Fitness for Use
The software is provided "AS IS" without any warranty, either expressed or
implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. You accept all risk as
to the performance of the software. In no way will Software with Brains, LLC
be liable for any damages or loss caused by the use, or inability to use this
software, regardless of its awareness of the potential for such damages or
loss. Software is complex, and by its very nature will contain defects.
Software with Brains, LLC may or may not attempt to correct such defects in
its software at its own discretion.

APPLICATION USAGE:
This application displays a window that contains the current TextPad
configuration folders locations and allows you to select a folder where
you would like to export this computer's TextPad configuration files.
This would normally be a network or removable drive like a flash drive.
A "TPConfig" folder will be created at the selected location and the
exported files will be stored within that folder.  This location must
be writable and you must have permission to create folders and files
in the selected location.

To import the configuration files on another computer, run the TPTransfer
application on the target computer and select the location where the
exported files were stored. Select the parent folder that *contains* the
TPConfig folder (do not select the TPConfig folder itself.  Then click
the button to import and the configuration files will be transferred to
the TextPad configuration folders that are specified in the application
window.

IMPORTANT: THE IMPORT PROCESS WILL OVERWRITE THE EXISTING TEXTPAD
CONFIGURATION FILES/SETTINGS ON THE TARGET COMPUTER!

You must already have TextPad installed on the target computer before
performing the import process so the application can determine where to
store the configuration files.

NOTE: The original ZIP package for this application contains the TPTRANSFER.EXE
file and this README.TXT file.  There is no "installer" and the application EXE
can simply be extracted from the ZIP file to the directory of your choice.
